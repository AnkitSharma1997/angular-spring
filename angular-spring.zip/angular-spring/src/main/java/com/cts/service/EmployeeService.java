package com.cts.service;

import com.cts.entity.Employee;

public interface EmployeeService {

	boolean saveEmployee(Employee employee);

}