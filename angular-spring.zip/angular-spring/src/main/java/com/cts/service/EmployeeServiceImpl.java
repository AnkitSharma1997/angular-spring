package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Employee;
import com.cts.repository.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao empDao;
	
	@Override
	public boolean saveEmployee(Employee employee) {
		if(empDao.persistEmployee(employee))
			return true;
		return false;
	}

}
