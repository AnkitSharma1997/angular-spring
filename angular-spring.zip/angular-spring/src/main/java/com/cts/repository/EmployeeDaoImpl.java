package com.cts.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.entity.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	
	@PersistenceContext
	private EntityManager manager;

	@Override
	@Transactional
	public boolean persistEmployee(Employee employee) {
		manager.persist(employee);
		
		return true;
	}
	
	@Override
	public boolean getById(Employee employee) {
		Employee checkEmployee  = (Employee)manager.createNamedQuery("findById");
		if(checkEmployee.getEmpId() !=null)
			return true;
		return false;
	}
}
